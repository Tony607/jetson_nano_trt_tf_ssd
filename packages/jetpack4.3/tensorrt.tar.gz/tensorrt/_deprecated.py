from .tensorrt import *

TensorFormat.NCHW = TensorFormat.LINEAR
TensorFormat.NC2HW2 = TensorFormat.CHW2
TensorFormat.NHWC8 = TensorFormat.HWC8

PluginFormat = TensorFormat
