import warnings
import os

SUPPRESS_DEPRECATION_WARNINGS = "TRT_SUPPRESS_DEPRECATION_WARNINGS" in os.environ and os.environ["TRT_SUPPRESS_DEPRECATION_WARNINGS"] == "1"

def warn_deprecated(reason="", version="5.0.0.0", stacklevel=2):
    if not SUPPRESS_DEPRECATION_WARNINGS:
        warnings.simplefilter('always', DeprecationWarning)
        warnings.warn(reason + "\nYou can suppress these warnings by setting `tensorrt.legacy._deprecated_helpers.SUPPRESS_DEPRECATION_WARNINGS=True` after importing, or setting the `TRT_SUPPRESS_DEPRECATION_WARNINGS` environment variable to 1", category=DeprecationWarning, stacklevel=stacklevel)
        warnings.simplefilter('default', DeprecationWarning)

def deprecated(func, use=None, reason="", version="5.0.0.0"):
    reason += (" Use " + use + " instead.") if use else ""
    def dep_func(*args, **kwargs):
        warn_deprecated(reason, version, stacklevel=3)
        return func(*args, **kwargs)
    return dep_func

def deprecated_property_readonly(getter, use=None, reason="", version="5.0.0.0"):
    return property(deprecated(getter, use, reason))

def deprecated_property_readwrite(getter, setter, use=None, reason="", version="5.0.0.0"):
    return property(deprecated(getter, use, reason), deprecated(setter, use, reason))

# Adds a getter to the specified class.
def deprecated_getter(trt_class, attr_name, getter_name=None):
    getter_name = "get_" + attr_name if not getter_name else getter_name
    setattr(trt_class, getter_name, deprecated(lambda this: getattr(this, attr_name), use=attr_name))

# Adds a setter to the specified class.
def deprecated_setter(trt_class, attr_name, setter_name=None):
    setter_name = "set_" + attr_name if not setter_name else setter_name
    setattr(trt_class, setter_name, deprecated(lambda this, val: setattr(this, attr_name, val), use=attr_name))

# Adds a getter/setter pair to the specified class.
def deprecated_getter_setter(trt_class, attr_name, getter_name=None, setter_name=None):
    deprecated_getter(trt_class, attr_name, getter_name)
    deprecated_setter(trt_class, attr_name, setter_name)
